import { assignActive } from "./setActive.mjs";
const $tradeMenuBtn = document.querySelectorAll(".small-menu-button");

assignActive($tradeMenuBtn);
